# ndpulsegen
The computer based software to communicate with the Narwhal Devices Pulse Counter
